%creates the basic problem structure
primitives = {'epub' 'epriv' 'develop'}; %vector of "primitive" characteristics each parcel possesses

C.offer1type = 'temp';
for ii=1:numel(primitives)
    eval(['C.ind.prim.' primitives{ii} ' = ii;'])
end  

%draw randoms
C.privRandOuts = {'epriv' 'develop'};
C.reg2ks = {'epub'};

for vi=1:numel(C.privRandOuts)
    C.privRandOutInds(vi) = eval(['C.ind.prim.' C.privRandOuts{vi}]);
end
for vi=1:numel(C.reg2ks)
    C.reg2kInds(vi) = eval(['C.ind.prim.' C.reg2ks{vi}]);
end

rng default
p = haltonset(numel(C.privRandOutInds)+numel(C.reg2kInds),'Skip',1e3,'Leap',1e2);
p = scramble(p,'RR2');

C.stdNormals1 = norminv(net(p,parcelNum));
C.stdNormals = norminv(net(p,parcelNum*regCasesNum));