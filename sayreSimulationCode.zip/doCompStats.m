clear all; close all;
dbstop if error

%set run specific parameters
G.interactive = 1;
parcelNum = 50;
regCasesNum = 100;

runID = datestr(now,'yyyymmdd_HHMMSS');
outputPath = fullfile('storedOutput',runID);
if ~exist(outputPath,'dir')
    mkdir(outputPath)
end
C.outputPath = outputPath;

%constant parameters
C.meanDevelop = 10;
C.varDevelop = 1;
C.discount = .95;

compStat = {
    'eprivStd'      'epriv mean is xx std devs below mean develop'              [1];
    'epubStd'       'epub is xx std devs above mean develop'                    [1.5];
    'G.developGr'   '(constant) growth rate of priv conversion value'           [0];
    'eprivVarRat'   'ratio of epriv var to develop var'                         [1];
    'epubVarRat'    'ratio of epub var tpo develop var'                         [1];
    'rhoEpubPriv'   'corr btwn public and priv env value'                       [0 .5 -.5];
    'rhoEpubD'      'corr btwn public env and develop value'                    [0 .5 -.5];
    'rhoEprivD'     'corr btwen priv env and develop value'                     [0 .5 -.5];
    'G.envQuad'     ''                                                          [0];
    'numPeriods'    ''                                                          [1];
    'G.fundCostP'   ''                                                          [1];
};

prepareCompStatArray
randomizationStructure

numPIcases = 5;
options = optimset('Display','off');
%conduct the comparative static loops
parfor ii=1:size(valArray,1)

    
    thisCase = ['case' num2str(ii)];
    [allValuesArray,gainArray,G] = prepareData(compStat,valArray(ii,:),C,thisCase);  
    
    if G.skipThisParamSet
        continue
    end
    %compute optimal single period offers with perfect info at mean values
    doTheseInds = (1:numPIcases);
    doTheseValues = allValuesArray(:,doTheseInds,:);
    thisGainArray = gainArray(:,doTheseInds,:);
    [piOffer(ii,:,:),piVal(ii,:),piExf(ii,:)] = piSolve(doTheseValues,thisGainArray,G,thisCase,options);
    
    %compute optimal single period offers with no info revealed in period 2
    offer0 = mean(mean((gainArray(:,2:end,3)>0).*gainArray(:,2:end,2)));

    %testni(ii) = land1Choice(mean(mean(gainArray(:,:,3))),allValuesArray,gainArray,G,'ni',['case' num2str(ii) 'ni']);
    disp(['starting ni solve case ii=' num2str(ii)])
    [offerNi,~,exfNi] = fmincon(@(x) -land1Choice(x,allValuesArray(:,2:end,:),gainArray(:,2:end,:),G,'ni',[thisCase 'ni']),offer0,[],[],[],[],0,Inf,'',options);
    niOffer(ii) = offerNi; niExf(ii) = exfNi;
    [expRegVal_ni(ii),expLandVal_ni(ii,:),optOffers_ni(ii,:),period1Choice_ni(ii,:)] = land1Choice(offerNi,allValuesArray(:,2:end,:),gainArray(:,2:end,:),G,'ni',[thisCase 'ni']);
    
    %compute optimal single period offers with all info revealed in period 2
    testl(ii) = land1Choice(offer0,allValuesArray(:,2:end,:),gainArray(:,2:end,:),G,'l',['case' num2str(ii) 'l']);     
    disp(['starting l solve case ii=' num2str(ii)])
    [offerL,~,exfL] = fmincon(@(x) -land1Choice(x,allValuesArray(:,2:end,:),gainArray(:,2:end,:),G,'l',[thisCase 'l']),offer0,[],[],[],[],0,Inf,'',options);
    lOffer(ii) = offerL; lExf(ii) = exfL;
    [expRegVal_l(ii),expLandVal_l(ii,:),optOffers_l(ii,:,:),period1Choice_l(ii,:)] = land1Choice(offerL,allValuesArray(:,2:end,:),gainArray(:,2:end,:),G,'l',[thisCase 'l']);
    
    
     %save(fullfile(outputPath,thisCase))
end

save(fullfile(outputPath,'fullResults'))
disp('Computed full run')    