function [expRegVal,expLandVal,optOffers,period1Choice] = land1Choice(offer1,allValuesArray,gainArray,G,flag,caseID)

if ~exist('flag','var')
    flag = 'l'; %set default flag to learning
end
%disp(['starting land1Choice, ' flag ', ' caseID])
%extract/set values that are constant over the looping
try
   load(fullfile(G.outputPath,['solGuesses/' caseID]))
catch
    period1Choice = G.ind.choice.delay*ones(size(allValuesArray,1),1); %initialize all parcels to delay
    offer0 = (gainArray(:,:,3)>0).*gainArray(:,:,2);
end



numChange = 10;
iter = 0;

switch G.offer1type
    case 'perm'
        offer1perm = offer1;
        offer1temp = 0*offer1;
    case 'temp'
        offer1perm = 0*offer1;
        offer1temp = offer1;
    case 'both'
        offer1perm = offer1(:,G.ind.offer1.perm);
        offer1temp = offer1(:,G.ind.offer1.temp);
end

%note that when allValues has multiple columns, they are all the same for develop and epriv
choices(:,G.ind.choice.convert) = allValuesArray(:,1,G.ind.prim.develop)*(1+(1+G.developGr)*G.payoff2Factor);
choices(:,G.ind.choice.conserve) = (offer1perm+allValuesArray(:,1,G.ind.prim.epriv))*(1+G.payoff2Factor);

options = optimset('Display','off','MaxFunEvals',10e5);
% options.showiter = 0;
% options.tol = 1e-4;
while numChange>0
    iter = iter+1;
    period1ChoiceOld = period1Choice;
    nonConvertibleParcels = find(period1Choice~=G.ind.choice.delay);
    %predict regulator choice given a set of period1 choices by landowners
    switch flag
        case 'ni'
            %no info will be revealed next period, can only make a single offer
            thisOffer0 = mean(mean(offer0));
            [optOffer,fval,exf] = fmincon(@(x) regObj2(x,period1Choice,allValuesArray,G),thisOffer0,[],[],[],[],0,Inf,'',options);
            [expPayoffReg2,expPayoffLand2] = regObj2(optOffer,period1Choice,allValuesArray,G);
            expValDelay = expPayoffLand2;
            for jj=1:numel(nonConvertibleParcels) 
                thisPeriod1Choice = period1Choice;
                thisInd = nonConvertibleParcels(jj);
                thisPeriod1Choice(thisInd) = G.ind.choice.delay;
                [~,expPayoff] = regObj2(optOffer,thisPeriod1Choice,allValuesArray,G);
                expValDelay(jj) = expPayoff(jj);
            end
            optOffers = optOffer;
       otherwise
            %I will learn everything next period (but might be nothing to reveal)
            %need to loop through possible realizations of info next period 
            optOffers = zeros(size(allValuesArray(:,:,1)));
            for ii=1:size(allValuesArray,2)
                %when I know everything, the second dimension of allValuesArray is 1
                thisOffer0 = offer0(period1Choice==G.ind.choice.delay,ii)+eps;
                %test = regObj2(thisOffer0,period1Choice,allValuesArray(:,ii,:),G);
                [optOffer,fval,exf] = fmincon(@(x) regObj2(x,period1Choice,allValuesArray(:,ii,:),G),thisOffer0,[],[],[],[],0*thisOffer0,Inf+thisOffer0,'',options);
                optOffers(period1Choice==G.ind.choice.delay,ii) = optOffer;      
                [expPayoffReg2(ii),expPayoffLand2(:,ii),expPayoffIfDelay(:,ii)] = regObj2(optOffer,period1Choice,allValuesArray(:,ii,:),G);
%                 for jj=1:numel(nonConvertibleParcels) 
%                     thisPeriod1Choice = period1Choice;
%                     thisInd = nonConvertibleParcels(jj);
%                     thisPeriod1Choice(thisInd) = G.ind.choice.delay;
%                     theseOffers = optOffers(thisPeriod1Choice==G.ind.choice.delay,ii);
%                     [thisOptOffer,thisfval,thisexf] = fmincon(@(x) singleObj(x,thisInd,theseOffers,thisPeriod1Choice,allValuesArray(:,ii,:),G),offer0(thisInd,ii)+eps,[],[],[],[],0,Inf,'',options);
%                     [~,expPayoffLand2(thisInd,ii)] = singleObj(thisOptOffer,thisInd,theseOffers,thisPeriod1Choice,allValuesArray(:,ii,:),G);
%                 end  
            end
        expValDelay = mean(expPayoffIfDelay,2); %integrate out envD, v1D, v2D, v2, and env to get expectation of landowner
    end
    %expValDelay is v1Cases x 1;
    choices(:,G.ind.choice.delay) = offer1temp + allValuesArray(:,1,G.ind.prim.epriv) + G.payoff2Factor*expValDelay; %note -- allValues has a nonzero second dimension, epriv is constant across dimensions
    choices = round(choices,4); %avoids flip-flopping due to functionally identical payoffs
    [expLandVal,period1Choice] = max(choices,[],2);
    numChange = numel(find(period1Choice-period1ChoiceOld));
%    fprintf('%d\n',numChange);
    if iter>100
        if G.interactive
            keyboard
        else
            disp('Cutting off iterations in land1Choice')
            save(['land1ChoiceState_' caseID])
            numChange=0;
        end
    end
end

conserve = (period1Choice==G.ind.choice.conserve);
convert = (period1Choice==G.ind.choice.convert);
delay = (period1Choice==G.ind.choice.delay);
totalSvcs1 = sum(repmat(conserve+delay,1,size(allValuesArray,2)).*allValuesArray(:,:,G.ind.prim.epub)); %sums across parcels
expectedEnvPayoff1 = mean(totalSvcs1 + G.envQuad*totalSvcs1.^2); %averages across cases

totalConv1 = sum(repmat(convert,1,size(allValuesArray,2)).*allValuesArray(:,:,G.ind.prim.develop));
expConvPayoff = mean(totalConv1);
expRegVal = expectedEnvPayoff1 + expConvPayoff - mean(expPayoffReg2)*G.payoff2Factor - G.fundCostP*(sum(offer1temp.*delay + offer1perm.*conserve));

if exist('caseID','var')
    if ~exist(fullfile(G.outputPath,'solGuesses'),'dir')
        mkdir(fullfile(G.outputPath,'solGuesses'))
    end
    if isscalar(optOffers)
        offer0 = max(.1,optOffers);
    else
        offer0(period1Choice==G.ind.choice.delay,:) = optOffers(period1Choice==G.ind.choice.delay,:);
    end
    save(fullfile(G.outputPath,'solGuesses',caseID),'period1Choice','offer0')
end