function  [piOffer,piVal,piExf] = piSolve(doTheseValues,thisGainArray,G,thisCase,options);

    for jj=1:size(doTheseValues,2)
        thisID = [thisCase '_' num2str(jj) 'pi'];
        thisOffer0 = (thisGainArray(:,jj,3)>0).*thisGainArray(:,jj,2) + eps;
        theseValues = doTheseValues(:,jj,:);
        theseGains = thisGainArray(:,jj,:);
%         testpi = land1Choice(thisOffer0,theseValues,theseGains,G,'pi',thisID);
%         tests(ii,jj) = testpi;
        disp(['starting pi solve ' thisCase ', jj=' num2str(jj) ])
        [piOffer(:,jj,:),piVal(:,jj),piExf(:,jj)] = fmincon(@(x) -land1Choice(x,doTheseValues(:,jj,:),thisGainArray(:,jj,:),G,'pi',thisID),thisOffer0,[],[],[],[],0*thisOffer0,Inf+thisOffer0,'',options);
    end
