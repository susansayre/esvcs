%matlab script to compute needed matrices from input values
function [allValuesArray,gainArray,G] = prepareData(compStat,valArray,C,thisCase)

%transfer current C values to G
G = C;

for jj=1:length(compStat)
    eval([compStat{jj,1} ' = valArray(jj);'])
end

muPrim(C.ind.prim.epub,:) = C.meanDevelop + epubStd*C.varDevelop^.5;
muPrim(C.ind.prim.epriv,:) = C.meanDevelop - eprivStd*C.varDevelop^.5;
muPrim(C.ind.prim.develop,:) = C.meanDevelop;

varVec(C.ind.prim.epub) = C.varDevelop*epubVarRat;
varVec(C.ind.prim.epriv) = eprivVarRat*C.varDevelop;
varVec(C.ind.prim.develop)= C.varDevelop;

sigmaPrim = zeros(numel(muPrim),numel(muPrim));
sigmaPrim(C.ind.prim.epub,C.ind.prim.epriv) = rhoEpubPriv*(varVec(C.ind.prim.epub)*varVec(C.ind.prim.epriv))^.5;
sigmaPrim(C.ind.prim.epub,C.ind.prim.develop) = rhoEpubD*(varVec(C.ind.prim.epub)*varVec(C.ind.prim.develop))^.5;
sigmaPrim(C.ind.prim.epriv,C.ind.prim.develop) = rhoEprivD*(varVec(C.ind.prim.epriv)*varVec(C.ind.prim.develop))^.5;
sigmaPrim = sigmaPrim + sigmaPrim' + diag(varVec);

if rank(sigmaPrim)<numel(muPrim)
    allValuesArray =[]; gainArray = []; G.skipThisParamSet = 1;
    return
    %check each variable type
else
    G.skipThisParamSet = 0;
end

parcelNum = size(C.stdNormals1,1);
regCasesNum = size(C.stdNormals,1)/parcelNum;

privRands = C.stdNormals1(:,1:numel(C.privRandOutInds))*cholcov(sigmaPrim(C.privRandOutInds,C.privRandOutInds)) + repmat(muPrim(C.privRandOutInds)',parcelNum,1);

transitionMat = sigmaPrim(C.reg2kInds,C.privRandOutInds)/sigmaPrim(C.privRandOutInds,C.privRandOutInds);
condVarMat = sigmaPrim(C.reg2kInds,C.reg2kInds) + transitionMat*sigmaPrim(C.privRandOutInds,C.reg2kInds);
condVarMat = cholcov(condVarMat);
privRandsRepeat = repmat(privRands,regCasesNum,1);

regCases = C.stdNormals(:,numel(C.privRandOutInds)+1:numel(C.reg2kInds)+numel(C.privRandOutInds))*condVarMat; 
regCases = regCases' + muPrim(C.reg2kInds)*ones(1,parcelNum*regCasesNum) + transitionMat*(privRandsRepeat' - repmat(muPrim(C.privRandOutInds),1,parcelNum*regCasesNum));
regCases = regCases';

for vi=1:numel(C.privRandOutInds);
    eval(['allValues(:,C.ind.prim.' C.privRandOuts{vi} ')= privRandsRepeat(:,vi);'])
end
for vi=1:numel(C.reg2kInds);
    eval(['allValues(:,C.ind.prim.' C.reg2ks{vi} ')=regCases(:,vi);'])
end

allValuesArray = reshape(allValues,[parcelNum regCasesNum numel(C.privRandOutInds) + numel(C.reg2kInds)]);

G.envLin = 1-G.envQuad*muPrim(C.ind.prim.epub);
r = 1/C.discount - 1;
if numPeriods == Inf
    G.payoff2Factor = 1/r;
else
    G.payoff2Factor = (1-1/(1+r)^numPeriods)/r;
end

%add the mean realizations of epub to the beginning of allValuesArray to use in my pi calcs
allValuesArray = [mean(allValuesArray,2) allValuesArray];

gainArray(:,:,1) = allValuesArray(:,:,G.ind.prim.epub) - allValuesArray(:,:,G.ind.prim.develop);
gainArray(:,:,2) = allValuesArray(:,:,G.ind.prim.develop) - allValuesArray(:,:,G.ind.prim.epriv);
gainArray(:,:,3) = (gainArray(:,:,2)>0).*(gainArray(:,:,1)>0).*max(0,(gainArray(:,:,1)-gainArray(:,:,2)));

save(fullfile(C.outputPath,thisCase))
