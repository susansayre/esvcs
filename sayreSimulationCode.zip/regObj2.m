function [expRegPayoff,expLandPayoff,expPayoffIfDelay] = regObj2(offerVector,previousChoice,randValues,G)
%returns the regulator's payoff in period 2 as a function of the vector of offers made to particular parcels
%when making offers, regulator knows what choice the parcel made last period, v1D, v2D, and envD
%offerVector and previousChoice are parcels x 1 vectors
%randValues is a parcels x randSamples x reg2unknowns array representing possible values for each consequential variable not known by
%the regulator in period2
%each column is equally likely

randCases = size(randValues,2); %will only be larger than 1 in my no info case

if numel(offerVector)>1 
        %only optimizing on offers for convertible parcels
        offerMat = zeros(size(randValues(:,:,1)));
        offerMat(previousChoice==G.ind.choice.delay,:)=offerVector;
else
    offerMat = offerVector;
end

convertible = repmat((previousChoice==G.ind.choice.delay),1,randCases);
conservedEarly = repmat((previousChoice==G.ind.choice.conserve),1,randCases);
develop2 = randValues(:,:,G.ind.prim.develop)*(1+G.developGr);
epriv = randValues(:,:,G.ind.prim.epriv);
epub = randValues(:,:,G.ind.prim.epub);

conservedNow = convertible.*(offerMat+epriv>develop2);
conservedAll = conservedNow + conservedEarly;
converted = 1-conservedAll; %this version assumes that land converted in period 1 yields v1 in that period and v2 for remaining periods

svcsTotal = sum(conservedAll.*epub); %1 x randCases vector of total svc values
valTotal = sum(converted.*develop2);
fundCostTotal = G.fundCostP*sum(conservedNow.*offerMat);

expRegPayoff = -mean(valTotal + G.envLin*svcsTotal - fundCostTotal + G.envQuad*svcsTotal.^2);
expLandPayoff = mean(max(offerMat+epriv,develop2),2);

expPayoffIfDelay = expLandPayoff;
dEnvPayoff = G.envLin +2*G.envQuad*svcsTotal;
costToChange = max(0,develop2 - epriv); %required payment to induce parcel to remain forested

parcelsMaybePaid = intersect(find(previousChoice~=G.ind.choice.delay),find(costToChange>0)); %parcels that didn't delay before and have to be induced to stay forested
worthPaying = find((repmat(dEnvPayoff,length(previousChoice),1).*epub - develop2 - costToChange>0)); %parcels whose benefit of remaining forested is greater than their cost

changeInds = intersect(worthPaying,parcelsMaybePaid);
expPayoffIfDelay(changeInds,:) = mean(develop2(changeInds,:),2); %regulator makes the parcels it wants to change whole


