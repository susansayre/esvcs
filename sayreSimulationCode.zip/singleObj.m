function[expRegPayoff,expLandPayoff] = singleObj(offer,idx,otherOffer,previousChoice,randValues,G)

offerVector = otherOffer;
convertedIdx = sum(previousChoice(1:idx)==G.ind.choice.delay);
offerVector(convertedIdx) = offer;
[expRegPayoff,expLandPayoffAll] = regObj2(offerVector,previousChoice,randValues,G);

expLandPayoff = expLandPayoffAll(idx);